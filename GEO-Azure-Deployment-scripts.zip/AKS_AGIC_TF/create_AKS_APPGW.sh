

RESOURCE_GROUP=geo-fms-micron-rg
terra_storage_acc=geofmsmicronterasa


# Set storage key as variable 
storage_acc_key=$(az storage account keys list --resource-group $RESOURCE_GROUP  --account-name $terra_storage_acc --query '[0].value' -o tsv)

terraform init -backend-config="storage_account_name=$terra_storage_acc" -backend-config="container_name=tfstate" -backend-config="access_key=$storage_acc_key" -backend-config="key=codelab.microsoft.tfstate"

terraform plan -out out.plan
terraform apply out.plan
